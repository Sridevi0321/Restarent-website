
  
# <h1> A Fully Functional Restaurant Website </h1> 

This is a restaurant website, offers a user-friendly interface that allows users to easily search good food at one place.

## [Live Preview of my website](https://veggievortex.vercel.app/)



Don't forget to :star: the repo if you like it :blush: 
